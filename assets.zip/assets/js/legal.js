(function () {
    'use strict';

    const PAGES = {
        tr: {
            backLabel: '← Ana Sayfaya Dön',
            updated: 'Son Güncelleme: Kasım 2026 · Veri Sorumlusu: LawLab Hukuk & Danışmanlık (Av. Ahmet Kerim TÜCER)',
            kvkk: {
                docTitle: 'KVKK Aydınlatma Metni | LawLab Hukuk & Danışmanlık',
                title: '6698 Sayılı Kişisel Verilerin Korunması Kanunu Kapsamında Aydınlatma Metni',
                sections: [
                    ['1. Veri Sorumlusunun Kimliği', '6698 sayılı Kişisel Verilerin Korunması Kanunu (“KVKK”) uyarınca kişisel verileriniz; veri sorumlusu sıfatıyla Fırat Mh. Mega Aslan Plaza A Blok Kat:8 No:42 Kayapınar / Diyarbakır adresinde faaliyet gösteren LawLab Hukuk & Danışmanlık — Av. Ahmet Kerim TÜCER tarafından aşağıda açıklanan kapsamda hukuka ve dürüstlük kurallarına uygun olarak işlenmektedir.'],
                    ['2. İşlenen Kişisel Veriler', 'İnternet sitemizdeki iletişim kanalları veya ön görüşme talepleriniz kapsamında paylaştığınız kimlik bilgileri (ad, soyad), iletişim bilgileri (telefon numarası, e-posta adresi), talep konusu hukuk alanı ve mesaj içeriği ile vekalet veya danışmanlık ilişkisi kurulması halinde mevzuatın gerektirdiği resmi dosya belgeleri işlenebilmektedir.'],
                    ['3. Kişisel Verilerin İşlenme Amaçları ve Hukuki Sebepleri', 'Kişisel verileriniz; iletişim ve randevu taleplerinizin yanıtlanması, hukuki ön değerlendirme süreçlerinin yürütülmesi, 1136 sayılı Avukatlık Kanunu ve ilgili mevzuattan doğan yükümlülüklerin yerine getirilmesi amaçlarıyla KVKK m. 5/2-(c), (ç) ve (f) hükümlerine dayanılarak işlenmektedir.'],
                    ['4. Kişisel Verilerin Aktarılması', 'Kişisel verileriniz, avukatlık meslek sırrı ilkesi çerçevesinde üçüncü kişilerle paylaşılmaz; yalnızca kanunen yetkili yargı mercileri, resmi kurumlar veya müvekkilin açık talimatı ve vekaleti doğrultusunda sınır ötesi başvuruların yürütüldüğü ilgili ülke resmi makamları ve çözüm ortağı baro avukatlarıyla sınırlı olarak paylaşılabilir.'],
                    ['5. KVKK Madde 11 Kapsamındaki Haklarınız', 'KVKK’nın 11. maddesi uyarınca kişisel verilerinizin işlenip işlenmediğini öğrenme, işlenmişse bilgi talep etme, düzeltilmesini veya silinmesini isteme haklarınıza ilişkin taleplerinizi info@lawlab.com.tr e-posta adresine veya merkez ofis adresimize yazılı olarak iletebilirsiniz.']
                ]
            },
            privacy: {
                docTitle: 'Gizlilik Politikası | LawLab Hukuk & Danışmanlık',
                title: 'Gizlilik ve Veri Güvenliği Politikası',
                sections: [
                    ['1. Mesleki Gizlilik Yaklaşımımız', 'LawLab Hukuk & Danışmanlık, hem 1136 sayılı Avukatlık Kanunu’nun 36. maddesinde düzenlenen sır saklama yükümlülüğü hem de ulusal veri koruma mevzuatı uyarınca ziyaretçilerinin ve müvekkillerinin gizliliğini temel meslek ilkesi olarak kabul eder.'],
                    ['2. Toplanan Bilgiler ve Kullanım Sınırı', 'lawlab.com.tr üzerinden iletilen bilgiler yalnızca iletişim kurulması, talep edilen hukuki konunun ön incelemesi ve randevu organizasyonu amacıyla kullanılır; hiçbir koşulda ticari pazarlama veya reklam amacıyla kullanılmaz.'],
                    ['3. Çerezler ve Yerel Depolama', 'İnternet sitemizde üçüncü taraf reklam veya profilleme çerezi kullanılmamaktadır. Yalnızca kullanıcının açık/koyu tema ve dil (TR/EN) tercihini hatırlamak amacıyla tarayıcı yerel depolama alanı (localStorage) teknik düzeyde kullanılmaktadır.'],
                    ['4. Teknik ve İdari Güvenlik', 'İletişim kanallarımız üzerinden paylaşılan bilgilerin yetkisiz erişime karşı korunması amacıyla güncel SSL/HTTPS şifreleme protokolleri ve erişim yetkilendirme tedbirleri uygulanmaktadır.']
                ]
            },
            disclaimer: {
                docTitle: 'Yasal Uyarı ve Meslek İlkeleri | LawLab Hukuk & Danışmanlık',
                title: 'Yasal Uyarı ve Meslek Kuralları Bilgilendirmesi',
                sections: [
                    ['1. Genel Bilgilendirme Niteliği', 'lawlab.com.tr internet sitesinde yer alan tüm yazılar, mevzuat özetleri, karşılaştırma tabloları ve yayınlar yalnızca genel bilgilendirme amacıyla hazırlanmıştır. Sitedeki hiçbir içerik hukuki danışmanlık, resmi hukuki mütalaa veya somut olaya uygulanacak kesin görüş niteliği taşımaz.'],
                    ['2. Avukat – Müvekkil İlişkisi', 'Bu internet sitesinin ziyaret edilmesi, sitedeki bilgilerin okunması veya iletişim formu/e-posta/telefon aracılığıyla bilgi talebinde bulunulması kendiliğinden avukat-müvekkil ilişkisi doğurmaz.'],
                    ['3. Türkiye Barolar Birliği Kurallarına Uyum', 'Bu internet sitesi, 1136 sayılı Avukatlık Kanunu’nun 55. maddesi, Türkiye Barolar Birliği Meslek Kuralları ve TBB Reklam Yasağı Yönetmeliği hükümlerine tam uyum gözetilerek, ticari reklam amacı taşımaksızın tanıtım ve hukuki bilgilendirme çerçevesinde tasarlanmıştır.'],
                    ['4. Güncellik ve Fikri Mülkiyet', 'Ulusal ve uluslararası mevzuat hükümleri zaman içinde değişiklik gösterebileceğinden, herhangi bir hukuki işlem tesis edilmeden önce uzman görüşü alınması önerilir. Sitedeki tasarım, logo ve özgün metin içerikleri LawLab Hukuk & Danışmanlık’a aittir; kaynak gösterilmeksizin çoğaltılamaz.']
                ]
            }
        },
        en: {
            backLabel: '← Back to Home',
            updated: 'Last Updated: November 2026 · Data Controller: LawLab Legal & Advisory (Att. Ahmet Kerim TÜCER)',
            kvkk: {
                docTitle: 'Data Protection Notice (KVKK) | LawLab Legal & Advisory',
                title: 'Personal Data Protection Notice Under Law No. 6698 (KVKK)',
                sections: [
                    ['1. Identity of the Data Controller', 'Pursuant to Turkish Personal Data Protection Law No. 6698 (“KVKK”), your personal data is processed lawfully and in good faith by LawLab Legal & Advisory — Att. Ahmet Kerim TÜCER, located at Fırat Dist. Mega Aslan Plaza Block A Floor:8 No:42 Kayapınar / Diyarbakır, Türkiye.'],
                    ['2. Categories of Processed Data', 'We may process identity details (full name), contact information (telephone number, email address), selected practice area, and inquiry summaries shared through our contact channels, alongside official file documentation where a formal legal mandate is established.'],
                    ['3. Purposes and Legal Grounds of Processing', 'Personal data is processed strictly to respond to consultation requests, conduct preliminary legal assessments, and fulfill statutory obligations under Attorneyship Law No. 1136 pursuant to Article 5/2-(c), (ç), and (f) of the KVKK.'],
                    ['4. Data Transfers & Confidentiality', 'Protected by strict attorney-client privilege, your data is never shared for commercial purposes and may only be disclosed to competent courts, public authorities, or locally licensed partner counsel abroad upon explicit client mandate.'],
                    ['5. Your Rights Under Article 11', 'You may exercise your rights of access, rectification, erasure, or objection under Article 11 of the KVKK by contacting info@lawlab.com.tr or submitting a written request to our head office.']
                ]
            },
            privacy: {
                docTitle: 'Privacy Policy | LawLab Legal & Advisory',
                title: 'Privacy & Data Security Policy',
                sections: [
                    ['1. Attorney-Client Confidentiality', 'LawLab Legal & Advisory upholds visitor and client confidentiality as a foundational obligation under Article 36 of Attorneyship Law No. 1136 and applicable data protection regulations.'],
                    ['2. Scope of Information Use', 'Information submitted via lawlab.com.tr is used exclusively for communication, preliminary evaluation of your inquiry, and appointment scheduling—never for commercial marketing.'],
                    ['3. Cookies & Technical Storage', 'Our website does not deploy third-party advertising or behavioral tracking cookies. Browser localStorage is utilized solely to remember your display theme (light/dark) and language (TR/EN) preference.'],
                    ['4. Security Measures', 'All communications with our website are protected via HTTPS/TLS encryption and strict administrative access controls.']
                ]
            },
            disclaimer: {
                docTitle: 'Legal Disclaimer & Professional Ethics | LawLab Legal & Advisory',
                title: 'Legal Disclaimer & Bar Ethics Notice',
                sections: [
                    ['1. Informational Purpose Only', 'All articles, statutory summaries, comparison tables, and briefings published on lawlab.com.tr are provided solely for general informational purposes and do not constitute formal legal advice or opinion.'],
                    ['2. No Automatic Attorney-Client Relationship', 'Visiting this website or transmitting a preliminary inquiry via form, email, or telephone does not by itself establish an attorney-client relationship.'],
                    ['3. Compliance with Bar Association Rules', 'This website has been prepared in full compliance with Article 55 of Turkish Attorneyship Law No. 1136, the Professional Rules of the Union of Turkish Bar Associations (TBB), and applicable regulations prohibiting commercial solicitation.'],
                    ['4. Legislative Updates & Intellectual Property', 'Because domestic and foreign statutes are subject to amendment, case-specific legal counsel should be obtained prior to acting. Website design, emblems, and original texts belong to LawLab Legal & Advisory.']
                ]
            }
        }
    };

    const root = document.querySelector('[data-legal-key]');
    if (!root) return;

    const pageKey = root.getAttribute('data-legal-key') || 'kvkk';
    const params = new URLSearchParams(window.location.search);
    const urlLang = (params.get('lang') || '').toLowerCase();
    let lang = urlLang === 'en' || urlLang === 'tr'
        ? urlLang
        : ((localStorage.getItem('lawlab_lang') || 'tr').toLowerCase() === 'en' ? 'en' : 'tr');

    const render = (nextLang) => {
        lang = nextLang === 'en' ? 'en' : 'tr';
        const dict = PAGES[lang];
        const page = dict[pageKey] || dict.kvkk;

        document.documentElement.lang = lang;
        document.title = page.docTitle;
        try { localStorage.setItem('lawlab_lang', lang); } catch (e) { /* ignore */ }

        const backEl = document.querySelector('[data-legal-back]');
        const titleEl = document.querySelector('[data-legal-title]');
        const updatedEl = document.querySelector('[data-legal-updated]');
        const bodyEl = document.querySelector('[data-legal-body]');

        if (backEl) {
            backEl.textContent = dict.backLabel;
            backEl.setAttribute('href', lang === 'en' ? 'index.html?lang=en' : 'index.html');
        }
        if (titleEl) titleEl.textContent = page.title;
        if (updatedEl) updatedEl.textContent = dict.updated;
        if (bodyEl) {
            bodyEl.innerHTML = page.sections
                .map(([h, p]) => `<h2>${h}</h2><p>${p}</p>`)
                .join('');
        }

        document.querySelectorAll('[data-lang-btn]').forEach((btn) => {
            btn.classList.toggle('active', btn.getAttribute('data-lang-btn') === lang);
        });
    };

    document.querySelectorAll('[data-lang-btn]').forEach((btn) => {
        btn.addEventListener('click', () => render(btn.getAttribute('data-lang-btn')));
    });

    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            const cur = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
            const nxt = cur === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-theme', nxt);
            try { localStorage.setItem('lawlab_theme', nxt); } catch (e) { /* ignore */ }
        });
    }

    render(lang);
})();
