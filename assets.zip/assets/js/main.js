(function () {
    'use strict';

    const WHATSAPP_NUMBER = '905322824323';
    const CONTACT_EMAIL = 'info@lawlab.com.tr';

    const I18N = {
        tr: {
            docTitle: 'LawLab Hukuk & Danışmanlık | Av. Ahmet Kerim TÜCER',
            metaDesc: 'Av. Ahmet Kerim TÜCER kuruculuğunda LawLab Hukuk & Danışmanlık; gayrimenkul ve imar hukuku, şirketler ve sözleşmeler, idare hukuku ile Avrupa ikamet ve sınır ötesi hukuki süreç yönetimi sunar.',
            skipLink: 'İçeriğe geç',
            topbarLocation: 'Fırat Mh. Mega Aslan Plaza Kat:8 No:42 · Kayapınar / Diyarbakır',
            brandSub: 'Av. Ahmet Kerim TÜCER',
            navAbout: 'Hakkımızda',
            navPractice: 'Çalışma Alanları',
            navInternational: 'Avrupa Masası',
            navPublications: 'Mevzuat & Yayınlar',
            navMethodology: 'Metodoloji',
            navContact: 'İletişim',
            navCta: 'Ön Görüşme Planla',
            heroBadge: 'Diyarbakır Merkez · Ulusal & Sınır Ötesi Hukuk Pratiği',
            heroTitle: 'Hukuki Güvenceyi <em>Analitik Stratejiyle</em> Buluşturuyoruz.',
            heroLead: 'Av. Ahmet Kerim TÜCER kuruculuğundaki LawLab; gayrimenkul ve imar hukukundan ticari sözleşmelere, idari uyuşmazlıklardan Avrupa Birliği oturum ve sınır ötesi mevzuat uyumuna kadar her dosyayı önleyici hukuk disipliniyle yönetir.',
            heroPrimaryCta: 'Hukuki Ön Değerlendirme',
            heroSecondaryCta: 'Çalışma Alanlarımızı İnceleyin',
            pillar1Title: 'Avukat Liderliği',
            pillar1Desc: 'Vekaletnameden resmi tescil ve dava aşamasına kadar doğrudan avukat takibi.',
            pillar2Title: 'Due Diligence Odağı',
            pillar2Desc: 'Tapu, imar, sözleşme ve idari belgelerde uyuşmazlık öncesi kapsamlı risk denetimi.',
            pillar3Title: 'Avrupa Koordinasyonu',
            pillar3Desc: 'Yunanistan ve Portekiz yerel baro avukatlarıyla entegre sınır ötesi süreç yönetimi.',
            portraitRole: 'Kurucu Avukat · LawLab Hukuk & Danışmanlık',
            portraitLoc: 'Kayapınar, Diyarbakır · Ulusal & Uluslararası Temsil',
            auth1: 'Önleyici Hukuk & Sözleşme Denetimi',
            auth2: 'Tapu, İmar & Gayrimenkul Due Diligence',
            auth3: 'Yunanistan & Portekiz İkamet Mevzuatı',
            auth4: 'Mesleki Sır Saklama & Şeffaf Raporlama',
            aboutEyebrow: 'Hakkımızda · Kurucu Vizyon',
            aboutTitle: 'Klasik Avukatlık Disiplinini Çağdaş Hukuk Mühendisliğiyle Birleştiriyoruz',
            aboutP1: 'Diyarbakır Kayapınar merkezli olarak faaliyet gösteren LawLab Hukuk & Danışmanlık, Av. Ahmet Kerim TÜCER tarafından müvekkillerine hem ulusal yargı ve danışmanlık süreçlerinde hem de sınır ötesi idari ve gayrimenkul işlemlerinde bütünsel hukuki güvence sunmak amacıyla kurulmuştur.',
            aboutP2: '“LawLab” yaklaşımının temelinde, hukuki meseleleri yalnızca uyuşmazlık doğduktan sonra savunulan dosyalar olarak değil; sözleşme mimarisi, tapu ve imar sicil taraması, idari uygunluk kontrolü ve mevzuat analiziyle baştan hatasız kurgulanan birer hukuk projesi olarak ele almak yer alır.',
            aboutP3: 'Yerel mahkemeler ve idari merciler nezdindeki dava ve takip pratiğimizin yanı sıra; Yunanistan ve Portekiz başta olmak üzere Avrupa oturum programları, yabancı ülke taşınmaz edinimleri, vekaletname (Power of Attorney) tesisi ve yerel barolara kayıtlı çözüm ortağı avukatlarla yürütülen çok katmanlı dosyalar tek merkezden koordine edilmektedir.',
            aboutQuote: '“Güçlü bir hukuki temsil, risk ortaya çıktığında verilen tepkiyle değil; risk doğmadan önce kurulan mevzuat ve belge disipliniyle ölçülür.”',
            prin1Title: 'Önleyici Hukuk ve Risk Analizi',
            prin1Desc: 'Ticari işlemler, taşınmaz alımları ve idari başvurular imzalanmadan önce tüm yasal kısıt ve yaptırım riskleri yazılı olarak denetlenir.',
            prin2Title: 'Doğrudan ve Şeffaf Süreç Takibi',
            prin2Desc: 'Müvekkillerimiz dosyanın her aşamasını, resmi başvuru kayıtlarını ve yasal süreleri doğrudan sorumlu avukat iletişimiyle takip eder.',
            prin3Title: 'Sınır Ötesi Mevzuat Uyumu',
            prin3Desc: 'Uluslararası dosyalarda apostil, konsolosluk tasdiki, resmi banka transfer kuralları ve hedef ülke göç/tapu mevzuatı eşzamanlı incelenir.',
            prin4Title: 'Meslek Etiği ve Gizlilik İlkesi',
            prin4Desc: '1136 sayılı Avukatlık Kanunu, TBB Meslek Kuralları ve 6698 sayılı KVKK çerçevesinde müvekkil mahremiyeti en üst standartta korunur.',
            practiceEyebrow: 'Uzmanlık & Faaliyet Alanları',
            practiceTitle: 'Çok Boyutlu Hukuki Danışmanlık ve Dava Vekilliği',
            practiceLead: 'Bireysel ve kurumsal müvekkillerimizin ihtiyaç duyduğu temel hukuk disiplinlerinde, mevzuata dayalı inceleme ve etkin temsil hizmeti sunuyoruz.',
            inspectScope: 'Hukuki Kapsamı İncele',
            intlEyebrow: 'Sınır Ötesi Hukuk · Avrupa Masası',
            intlTitle: 'Yunanistan ve Portekiz İkamet & Taşınmaz Hukuku Koordinasyonu',
            intlLead: 'Avrupa oturum başvurularını bir pazarlama faaliyeti değil, sıkı denetlenen bir idare ve taşınmaz hukuku süreci olarak ele alıyor; Diyarbakır merkez ofisimiz ve ilgili ülke barolarına kayıtlı yerel avukatlarımızla uçtan uca yürütüyoruz.',
            greeceDeskLabel: 'Yunanistan Hukuk Masası',
            greeceDeskTitle: 'Taşınmaz Due Diligence, Dönüşüm (Conversion) Denetimi ve Oturum Başvurusu',
            greeceDeskDesc: 'Yunanistan Yeni Göç Kodu (5038/2023) ve 5100/2024 sayılı Kanun değişiklikleri sonrasında bölgesel alt sınırlar, 120 m² tek taşınmaz şartı ve 250.000 € ticari dönüşüm/restorasyon istisnaları titiz hukuki denetim gerektirmektedir.',
            grStep1: 'Konsolosluk veya noter huzurunda Vekaletname (PoA), Yunan Vergi Numarası (AFM) ve banka hesabı tesisi.',
            grStep2: 'Tapu Sicil (Ktimatologio) ipotek/şerh taraması ve ticari dönüşüm projelerinde belediye imar ruhsatı kontrolü.',
            grStep3: 'Noterlik Satış Sözleşmesi (Symvolaio), tescil (Metagrafi), e-Paravolo ve dijital White Paper başvurusu.',
            grStep4: 'Kısa dönem kiralama (Airbnb) ve şirket merkezi tescil yasaklarına (50.000 € idari yaptırım riski) karşı sözleşmesel koruma.',
            grMetric1Label: 'Aile Kapsamı',
            grMetric1Val: '3 Kuşak Aile Birleşimi',
            grMetric2Label: 'Fiziki İkamet Şartı',
            grMetric2Val: '0 Gün (Mülkiyet Esaslı)',
            grMetric3Label: 'Ortalama Süreç',
            grMetric3Val: '4 – 6 Ay',
            portugalDeskLabel: 'Portekiz Hukuk Masası',
            portugalDeskTitle: 'Golden Visa Mevzuat Uyumu, D7 İkamet Vizesi ve Vatandaşlık Planlaması',
            portugalDeskDesc: 'Portekiz Yabancılar Yasası (23/2007) ve AIMA nezdindeki idari yeniden yapılanma çerçevesinde; uygunluk belgeleri, mali temsilcilik ve uzun dönemli vatandaşlık rotası Portekiz Barosu\'na kayıtlı uzmanlarla koordineli yürütülür.',
            ptStep1: 'Portekiz Vergi Kimlik Numarası (NIF) alımı, mali temsilcilik ve banka hesabı uyum süreçleri.',
            ptStep2: 'Adli sicil, nüfus ve gelir/uygunluk belgelerinin apostil ve tasdik standartlarına göre hazırlanması.',
            ptStep3: 'AIMA dijital portal başvurusu, biyometrik randevu takibi ve hak kaybını önleyici idari yazışmalar.',
            ptStep4: 'D7 Pasif Gelir Vizesi başvurularında vergi mukimliği (tax residency) ve ikamet süresi hukuki analizi.',
            ptMetric1Label: 'Minimal Stay',
            ptMetric1Val: 'Yılda Ortalama 7 Gün',
            ptMetric2Label: 'Vatandaşlık Rotası',
            ptMetric2Val: '5 Yıl + A2 Dil Şartı',
            ptMetric3Label: 'Aile Birleşimi',
            ptMetric3Val: 'Madde 98 Kapsamı',
            compTitle: 'Mevzuat Karşılaştırma Özeti: Yunanistan & Portekiz',
            compSub: 'Başvuru sahibinin aile yapısı, fiziksel kalış esnekliği ve uzun vadeli vatandaşlık hedeflerine göre hukuki çerçeve farkları.',
            compCta: 'Dosya Uygunluk Analizi İste',
            thCriteria: 'Hukuki Kriter',
            thGreece: 'Yunanistan (5038/2023 & 5100/2024)',
            thPortugal: 'Portekiz (Lei 23/2007 & 56/2023)',
            row1Head: 'Temel Hukuki Odak',
            row1Gr: 'Taşınmaz mülkiyeti, tapu sicil tescili (Metagrafi) ve imar/dönüşüm ruhsat uygunluğu',
            row1Pt: 'Düzenlemeye tabi başvuru uygunluğu, belge standardı ve AIMA idari onay takibi',
            row2Head: 'Aile Birleşimi',
            row2Gr: 'Üç kuşak: eş, 21 yaş altı çocuklar (24\'e uzatılabilir) ve her iki eşin anne-babası',
            row2Pt: 'Madde 98 uyarınca eş, küçük/öğrenci bağımlı çocuklar ve bakmakla yükümlü olunan ebeveynler',
            row3Head: 'Yıllık Kalış Yükümlülüğü',
            row3Gr: 'Oturumu korumak için 0 gün fiziki kalış şartı (mülkiyetin devamı esastır)',
            row3Pt: 'Golden Visa\'da yılda ortalama 7 gün; D7 İkamet Vizesinde yılda 6–8 ay fiili ikamet',
            row4Head: 'Vatandaşlık Şartları',
            row4Gr: '7 yıl kesintisiz fiili ikamet (yılda ≥183 gün), vergi mukimliği ve Yunanca dil/kültür sınavı',
            row4Pt: '5 yıllık yasal ikamet süresinin tamamlanması, adli temizlik ve A2 düzeyinde Portekizce',
            pubEyebrow: 'LawLab Hukuk Bülteni',
            pubTitle: 'Mevzuat Analizleri ve Uygulama Rehberleri',
            pubLead: 'Güncel kanun değişiklikleri, taşınmaz hukuki inceleme kriterleri ve sınır ötesi idari başvuru usullerine dair bilgi notlarımız.',
            filterAll: 'Tümü',
            filterIntl: 'Uluslararası İkamet',
            filterRe: 'Gayrimenkul & İmar',
            filterProc: 'Usul & Sözleşme',
            readArticleBtn: 'İncelemeyi Oku →',
            readArticleLink: 'Tam Metni İncele',
            featuredHighlightsTitle: 'İnceleme Başlıkları',
            methodEyebrow: 'Çalışma Metodolojimiz',
            methodTitle: 'Her Dosyada Dört Aşamalı Hukuki Denetim Mimarisini Uyguluyoruz',
            step1Title: 'Ön Değerlendirme & Mevzuat Haritası',
            step1Desc: 'Uyuşmazlık konusu veya hedeflenen işlem dinlenir; uygulanacak ulusal/uluslararası kanun hükümleri, süreler ve olası riskler netleştirilir.',
            step2Title: 'Hukuki Due Diligence & Belge Kontrolü',
            step2Desc: 'Tapu sicili, imar dosyası, ticari kayıtlar ve resmi evraklar incelenerek işlem öncesi hukuki uygunluk raporu hazırlanır.',
            step3Title: 'Sözleşme Kurulumu & Resmi Başvuru',
            step3Desc: 'Müvekkil haklarını koruyan özelleştirilmiş sözleşmeler hazırlanır; mahkeme, tapu veya göç idaresi başvuruları usulüne uygun tamamlanır.',
            step4Title: 'Şeffaf Raporlama & Sonuçlandırma',
            step4Desc: 'İdari onay, duruşma, biyometri ve tescil aşamaları düzenli olarak raporlanır; nihai karar ve resmi belgeler güvenle teslim edilir.',
            faqEyebrow: 'Sıkça Sorulan Sorular',
            faqTitle: 'Süreç ve Hukuki Temsile Dair Merak Edilenler',
            faqLead: 'Vekaletname düzenlenmesi, taşınmaz incelemeleri ve sınır ötesi başvuru süreçlerine ilişkin genel bilgilendirme yanıtları.',
            contactEyebrow: 'İletişim & Randevu',
            contactTitle: 'Hukuki Süreciniz İçin Doğrudan İletişime Geçin',
            contactDesc: 'Dosyanızın mevzuata uygunluğunu değerlendirmek, sözleşme ve dava süreçlerinizi planlamak üzere merkez ofisimizden randevu talep edebilirsiniz.',
            contactLawyerLabel: 'Kurucu Avukat',
            contactOfficeLabel: 'Merkez Ofis',
            contactPhoneLabel: 'Telefon & WhatsApp',
            contactEmailLabel: 'Kurumsal E-Posta',
            contactHoursLabel: 'Çalışma Saatleri',
            contactHoursVal: 'Pazartesi – Cuma · 09:00 – 18:00',
            waDirectBtn: 'WhatsApp ile İletişim',
            mapDirectionsBtn: 'Haritada Yol Tarifi',
            formHeading: 'Ön Görüşme ve Bilgi Talebi Formu',
            formSubheading: 'Bilgilerinizi iletin; talebiniz çalışma saatleri içerisinde incelenerek tarafınıza dönüş sağlansın.',
            labelName: 'Ad Soyad *',
            labelPhone: 'Telefon *',
            labelEmail: 'E-Posta *',
            labelTopic: 'İlgili Hukuk Alanı *',
            labelMessage: 'Konu Özeti *',
            phName: 'Adınız Soyadınız',
            phPhone: '+90 (5xx) xxx xx xx',
            phEmail: 'ornek@eposta.com',
            phMessage: 'Hukuki talebinizin veya sürecinizin ana hatlarını kısaca paylaşabilirsiniz...',
            optSelect: 'Seçiniz...',
            optIntl: 'Yabancılar & Avrupa İkamet Hukuku (Yunanistan / Portekiz)',
            optRe: 'Gayrimenkul, Tapu & İmar Hukuku',
            optCorp: 'Şirketler, Ticaret & Sözleşmeler Hukuku',
            optAdmin: 'İdare & Vergi Hukuku',
            optEnf: 'İcra, İflas & Alacak Takibi',
            optLabor: 'İş Hukuku, Arabuluculuk & Özel Hukuk',
            consentHtml: '<a href="kvkk.html">KVKK Aydınlatma Metni</a>\'ni okudum; iletişim talebimin değerlendirilmesi amacıyla kişisel verilerimin işlenmesini kabul ediyorum.',
            submitBtn: 'Ön Görüşme Talebi Oluştur',
            footerDesc: 'Ulusal dava ve danışmanlık pratiğini sınır ötesi taşınmaz, yatırım ve Avrupa ikamet mevzuatı uzmanlığıyla birleştiren hukuk ve danışmanlık bürosu.',
            footerNavTitle: 'Kurumsal',
            footerLegalTitle: 'Yasal & Uyum',
            footerContactTitle: 'İletişim',
            linkKvkk: 'KVKK Aydınlatma Metni',
            linkPrivacy: 'Gizlilik Politikası',
            linkDisclaimer: 'Yasal Uyarı & Meslek İlkeleri',
            footerEthicalNotice: 'Yasal Bilgilendirme: Bu internet sitesinde yer alan bilgi, mevzuat özeti ve yayınlar yalnızca genel bilgilendirme amacıyla sunulmakta olup hukuki mütalaa, danışmanlık veya reklam niteliği taşımaz. Her somut olay kendi dosya kapsamı ve güncel mevzuat çerçevesinde ayrıca değerlendirilir. Bu site Türkiye Barolar Birliği Meslek Kuralları ve 1136 sayılı Avukatlık Kanunu hükümlerine uygun olarak hazırlanmıştır.',
            copyright: '© 2026 LawLab Hukuk & Danışmanlık — Av. Ahmet Kerim TÜCER. Tüm hakları saklıdır.',
            modalFootNote: 'Genel bilgilendirme amaçlıdır; dosya özelinde değerlendirme için iletişime geçiniz.',
            modalCta: 'Bu Konuda Görüşme Planla',
            formValidationErr: 'Lütfen tüm zorunlu alanları doldurun ve KVKK aydınlatma onayını işaretleyin.',
            formReadyMsg: 'Talebiniz özeti oluşturuldu. Aşağıdaki kanallardan biriyle doğrudan merkez ofisimize iletebilirsiniz:',
            sendViaWa: 'WhatsApp ile Gönder',
            sendViaMail: 'E-Posta ile Gönder',
            practices: [
                {
                    topicKey: 'international',
                    kicker: 'Uzmanlık Alanı · YUKK, 5038/2023 & 23/2007',
                    title: 'Yabancılar, Göç ve Avrupa İkamet Hukuku',
                    summary: 'Yunanistan ve Portekiz başta olmak üzere Avrupa oturum programları, D7 ikamet vizeleri, aile birleşimi ve vatandaşlık başvurularında uçtan uca hukuki koordinasyon.',
                    bullets: [
                        'Konsolosluk & Noterlik Vekaletname (PoA) kurulumu',
                        'Golden Visa & D7 ikamet dosyası uygunluk denetimi',
                        'Çok kuşaklı aile birleşimi ve kart yenileme takibi'
                    ],
                    modalHtml: `
                        <p>Avrupa Birliği ülkelerinde oturum izni ve uzun dönemli ikamet başvuruları, sıkı şekil şartlarına ve idari denetime tabi hukuki prosedürlerdir. LawLab, başvuru sahibinin ve ailesinin hak kaybına uğramaması için süreci doğrudan ilgili ülke mevzuatına göre yapılandırır.</p>
                        <h4>Hukuki Hizmet Kapsamımız</h4>
                        <ul>
                            <li>Yunanistan 5038/2023 (Madde 100) ve 5100/2024 sayılı Kanunlar kapsamında taşınmaz edinimine dayalı Golden Visa başvurularının yürütülmesi.</li>
                            <li>Portekiz 23/2007 ve 56/2023 sayılı Kanunlar çerçevesinde Golden Visa ve D7 Pasif Gelir İkamet Vizesi dosyalarının hazırlanması ve AIMA takibi.</li>
                            <li>Yunanistan Başkonsolosluğu, Portekiz temsilcilikleri ve noterlikler nezdinde Vekaletname (Power of Attorney) metinlerinin hazırlanması ve apostil denetimi.</li>
                            <li>Yabancı vergi kimlik numaralarının (AFM / NIF) alınması, banka hesabı uyumu ve resmi ödeme transferlerinin (Wire Transfer) yasal standartlara uygunluğunun kontrolü.</li>
                            <li>Eş, çocuklar ve uygun programlarda ebeveynleri kapsayan aile birleşimi başvuruları ile 5 yıllık oturum kartı yenileme ve vatandaşlık uygunluk değerlendirmeleri.</li>
                        </ul>
                    `
                },
                {
                    topicKey: 'realestate',
                    kicker: 'Uzmanlık Alanı · TMK, 3194 İmar Kanunu & Tapu Hukuku',
                    title: 'Gayrimenkul, Tapu ve İmar Hukuku',
                    summary: 'Yurt içi ve sınır ötesi taşınmaz yatırımlarında tapu takyidat incelemesi, imar ve dönüşüm (conversion) ruhsat kontrolü ile satış sözleşmelerinin hazırlanması.',
                    bullets: [
                        'Tapu sicil, ipotek, haciz ve şerh temizlik raporu',
                        'İmar planı, yapı ruhsatı ve dönüşüm projesi denetimi',
                        'Tapu iptal-tescil, kira ve kat mülkiyeti davaları'
                    ],
                    modalHtml: `
                        <p>Gerek Türkiye içindeki gayrimenkul projelerinde gerekse yurt dışı taşınmaz alımlarında en kritik aşama, sözleşme imzalanmadan ve bedel aktarılmadan önce yapılan <strong>Hukuki Durum Tespiti (Due Diligence)</strong> incelemesidir.</p>
                        <h4>Hukuki Hizmet Kapsamımız</h4>
                        <ul>
                            <li>Tapu kütüğü ve kadastro kayıtları üzerinde ipotek, haciz, intifa, kira şerhi ve mülkiyet ihtilaflarının detaylı taranması.</li>
                            <li>Belediye imar dosyaları, yapı ruhsatları, iskan (yapı kullanma izni) ve ticari mülkten konuta dönüşüm (conversion) izinlerinin yasal uygunluk kontrolü.</li>
                            <li>Arsa payı karşılığı inşaat (kat karşılığı) sözleşmeleri, taşınmaz satış vaadi ve noterlik satış sözleşmelerinin müvekkil lehine koruyucu hükümlerle hazırlanması.</li>
                            <li>Tapu iptali ve tescil, ortaklığın giderilmesi (izale-i şüyu), müdahalenin men'i, ecrimisil ve kamulaştırma davalarında dava vekilliği.</li>
                            <li>Ticari ve konut kira sözleşmelerinin hazırlanması, kira tespiti ve tahliye uyuşmazlıklarının takibi.</li>
                        </ul>
                    `
                },
                {
                    topicKey: 'corporate',
                    kicker: 'Uzmanlık Alanı · 6102 TTK & 6098 TBK',
                    title: 'Şirketler, Ticaret ve Sözleşmeler Hukuku',
                    summary: 'Şirketlerin kurumsal işleyişi, ticari sözleşmelerin müzakeresi, pay devri işlemleri ve uluslararası ödeme/bankacılık uyumu süreçlerinde önleyici danışmanlık.',
                    bullets: [
                        'Ticari satış, eser, kira ve ortaklık sözleşmeleri',
                        'Şirket kuruluşu, esas sözleşme ve genel kurul işlemleri',
                        'Sınır ötesi banka transfer ve sözleşme uyumu'
                    ],
                    modalHtml: `
                        <p>Ticari hayatta karşılaşılan uyuşmazlıkların büyük bölümü matbu veya belirsiz hükümler içeren sözleşmelerden kaynaklanır. LawLab, ticari ilişkileri imza aşamasından önce sağlam bir sözleşme mimarisine oturtur.</p>
                        <h4>Hukuki Hizmet Kapsamımız</h4>
                        <ul>
                            <li>Anonim ve limited şirket kuruluşları, esas sözleşme tadilleri, genel kurul ve yönetim kurulu karar süreçlerinin yürütülmesi.</li>
                            <li>Hisse devir sözleşmeleri, pay sahipleri sözleşmeleri (SHA), gizlilik (NDA), tedarik, distribütörlük ve hizmet sözleşmelerinin hazırlanması ve müzakeresi.</li>
                            <li>Sürekli kurumsal hukuk müşavirliği kapsamında şirket içi hukuki uyum (compliance) ve risk denetimi.</li>
                            <li>Uluslararası ticari işlemlerde resmi ödeme kanalları, banka transfer kuralları ve cezai şart hükümlerinin yapılandırılması.</li>
                        </ul>
                    `
                },
                {
                    topicKey: 'administrative',
                    kicker: 'Uzmanlık Alanı · 2577 İYUK & Vergi Mevzuatı',
                    title: 'İdare ve Vergi Hukuku',
                    summary: 'Kamu idareleri ve belediyelerin tesis ettiği idari işlemlere karşı iptal ve tam yargı davaları ile ulusal/uluslararası vergi kimlik ve mükellefiyet takibi.',
                    bullets: [
                        'İdari işlemin iptali ve yürütmenin durdurulması',
                        'Belediye, ruhsat ve imar para cezası itirazları',
                        'Yurt dışı vergi kimliği (AFM / NIF) ve çifte vergilendirme'
                    ],
                    modalHtml: `
                        <p>İdarenin tesis ettiği işlemler hukuka uygunluk karinesinden yararlanır ancak sıkı hak düşürücü sürelere tabidir. İdari uyuşmazlıklarda süresinde ve teknik gerekçelerle başvuru yapılması hak kaybını önler.</p>
                        <h4>Hukuki Hizmet Kapsamımız</h4>
                        <ul>
                            <li>Belediyeler, bakanlıklar ve düzenleyici kurumlarca tesis edilen idari para cezaları, ruhsat iptalleri ve imar işlemlerine karşı yürütmenin durdurulması istemli iptal davaları.</li>
                            <li>İdari eylem ve işlemlerden doğan zararların tazmini amacıyla tam yargı davalarının açılması ve takibi.</li>
                            <li>Vergi tarhiyatı, vergi ziyaı cezaları ve uzlaşma süreçlerinde hukuki temsil.</li>
                            <li>Yurt dışı ikamet ve mülkiyet süreçlerinde yabancı vergi numarası (AFM / NIF) tesisi ve vergi mukimliği (tax residency) statüsünün değerlendirilmesi.</li>
                        </ul>
                    `
                },
                {
                    topicKey: 'enforcement',
                    kicker: 'Uzmanlık Alanı · 2004 İİK & Alacak Yönetimi',
                    title: 'İcra, İflas ve Alacak Hukuku',
                    summary: 'Ticari ve bireysel alacakların etkin tahsili, teminatların paraya çevrilmesi, ihtiyati haciz kararları ile menfi tespit ve istirdat davalarının yürütülmesi.',
                    bullets: [
                        'İlamlı, ilamsız ve kambiyo senetlerine özgü takipler',
                        'İhtiyati haciz, rehin ve ipotek takipleri',
                        'İtirazın iptali, menfi tespit ve tasarrufun iptali'
                    ],
                    modalHtml: `
                        <p>Alacakların zamanında ve hukuka uygun araçlarla tahsili ticari süreklilik açısından hayati önem taşır. Aynı şekilde haksız icra tehditlerine karşı borçlu haklarının korunması da hızlı usul işlemleri gerektirir.</p>
                        <h4>Hukuki Hizmet Kapsamımız</h4>
                        <ul>
                            <li>Çek, bono ve poliçelere dayalı kambiyo senetlerine özgü haciz yoluyla takip işlemleri ve ihtiyati haciz kararlarının alınması.</li>
                            <li>İpoteğin ve rehnin paraya çevrilmesi yoluyla icra takiplerinin yürütülmesi.</li>
                            <li>İtirazın iptali, itirazın kaldırılması, menfi tespit, istirdat ve mal kaçırma işlemlerine karşı tasarrufun iptali davaları.</li>
                            <li>Borç yapılandırma ve sulh/ibra protokollerinin hukuki güvenceyle hazırlanması.</li>
                        </ul>
                    `
                },
                {
                    topicKey: 'labor',
                    kicker: 'Uzmanlık Alanı · 4857 İş Kanunu & Özel Hukuk',
                    title: 'İş Hukuku, Tazminat ve Arabuluculuk',
                    summary: 'İşveren ve çalışan ilişkilerinin mevzuata uyumu, zorunlu ve ihtiyari arabuluculuk oturumlarında taraf vekilliği ile tazminat ve miras hukuku uyuşmazlıkları.',
                    bullets: [
                        'İş sözleşmeleri, fesih yönetimi ve işçilik alacakları',
                        'Ticari ve iş uyuşmazlıklarında arabuluculuk temsili',
                        'Maddi-manevi tazminat ve miras paylaşım işlemleri'
                    ],
                    modalHtml: `
                        <p>İş ilişkilerinin kurulmasından sona ermesine kadar olan süreçte usul kurallarına uyulması, ileride doğabilecek yüksek tazminat yüklerini önler.</p>
                        <h4>Hukuki Hizmet Kapsamımız</h4>
                        <ul>
                            <li>İş sözleşmeleri, özlük dosyaları, disiplin yönetmelikleri ve haklı/geçerli fesih bildirimlerinin İş Kanunu'na uygun hazırlanması.</li>
                            <li>İşe iade, kıdem-ihbar tazminatı ve fazla mesai alacaklarına ilişkin dava ve zorunlu arabuluculuk süreçlerinde taraf vekilliği.</li>
                            <li>Haksız fiil ve sözleşmeye aykırılıktan kaynaklanan maddi ve manevi tazminat davaları.</li>
                            <li>Veraset ilamı, vasiyetname düzenlenmesi, tenkis ve miras taksim sözleşmelerinin yürütülmesi.</li>
                        </ul>
                    `
                }
            ],
            publications: [
                {
                    topicKey: 'international',
                    categoryLabel: 'Uluslararası İkamet Hukuku',
                    readTime: '6 dk okuma',
                    title: '5038/2023 ve 5100/2024 Sayılı Kanunlar Çerçevesinde Yunanistan Golden Visa Mevzuatı ve Kullanım Kısıtları',
                    excerpt: 'Yunanistan Yeni Göç Kodu\'nun 100. maddesi, 800.000 € / 400.000 € bölgesel eşikler, 250.000 € ticari dönüşüm istisnası ile kısa dönem kiralama (Airbnb) yasağının hukuki sonuçları.',
                    highlights: [
                        '5038/2023 Sayılı Kanun Madde 100 Çerçevesi',
                        '5100/2024 Bölgesel Alt Sınırlar ve 120 m² Kuralı',
                        '250.000 € Ticari Dönüşüm & Restorasyon İstisnası',
                        '50.000 € İdari Para Cezası ve İptal Yaptırımları'
                    ],
                    modalHtml: `
                        <p>Yunanistan Golden Visa programının ana hukuki çerçevesi <strong>5038/2023 Sayılı Kanun (Yeni Göç Kodu) Madde 100</strong> ile çizilmiş; <strong>5100/2024 Sayılı Kanun (Madde 64)</strong> ve Göç Bakanlığı'nın <strong>6/2024 sayılı Uygulama Genelgesi</strong> ile bölgesel alt sınırlar ve mülk kullanım kuralları yeniden düzenlenmiştir.</p>
                        <h4>1. Bölgesel Başvuru Limitleri ve Tek Mülk Şartı</h4>
                        <ul>
                            <li><strong>800.000 € Bölgesi:</strong> Attika Bölgesi (Atina ve çevresi), Selanik, Mikonos, Santorini ve nüfusu 3.100'ün üzerindeki adalarda minimum taşınmaz bedeli 800.000 € olarak uygulanır.</li>
                            <li><strong>400.000 € Bölgesi:</strong> Yukarıda sayılan bölgelerin dışındaki diğer anakara ve taşra bölgelerinde alt sınır 400.000 € olarak belirlenmiştir.</li>
                            <li><strong>120 m² ve Tek Taşınmaz Şartı:</strong> Her iki kademede de başvurunun tek bir bağımsız bölüm üzerinden yapılması ve net alanın en az 120 m² olması zorunludur.</li>
                        </ul>
                        <h4>2. İstisnai 250.000 € Rotaları</h4>
                        <ul>
                            <li><strong>Ticari Mülk Dönüşümü (Conversion):</strong> Fabrika, ofis veya depo gibi ticari/endüstriyel nitelikteki bir mülkün yasal imar izinleriyle konuta dönüştürülmesi projeleri.</li>
                            <li><strong>Tescilli Bina Restorasyonu:</strong> Tarihi veya mimari koruma altındaki tescilli yapıların tamamen restore edilmesi şartına bağlı projeler.</li>
                        </ul>
                        <h4>3. Kritik Kullanım Yasakları ve Cezai Müeyyideler</h4>
                        <p>Yeni mevzuat uyarınca 100. madde kapsamında edinilen taşınmazların Airbnb veya benzeri platformlarda <strong>kısa dönemli kiraya verilmesi</strong> ya da <strong>şirket merkezi/şubesi olarak tescil edilmesi</strong> kesin olarak yasaklanmıştır. İhlal halinde <strong>50.000 € idari para cezası</strong> uygulanmakta ve oturum izni iptal edilmektedir.</p>
                    `
                },
                {
                    topicKey: 'international',
                    categoryLabel: 'Usul & Sözleşme Hukuku',
                    readTime: '7 dk okuma',
                    title: 'Sınır Ötesi İşlemlerde Vekaletname (PoA), Due Diligence ve Resmi Ödeme Kuralları',
                    excerpt: 'Konsolosluk vekaletnamesinden tapu sicil araştırmasına, banka havalesi zorunluluğundan White Paper ve biyometri aşamasına kadar 5 adımlı hukuki işlem haritası.',
                    modalHtml: `
                        <p>Yurt dışı taşınmaz edinimi ve buna bağlı ikamet başvuruları, ticari bir pazarlama sürecinden ziyade milimetrik usul kurallarına bağlı idari bir hukuk sürecidir. İşlemler beş temel hukuki aşamada yürütülür:</p>
                        <h4>Aşama 1: Vekaletname (PoA), AFM ve Banka Süreci</h4>
                        <p>İşlemlerin gıyabınızda yürütülebilmesi için noter huzurunda veya ilgili Başkonsoloslukta özel yetkili Vekaletname (Power of Attorney) düzenlenir. Ardından Yabancılar Vergi Dairesi'nden vergi kimlik numarası (AFM) alınır ve resmi ödeme takibi için banka süreçleri başlatılır.</p>
                        <h4>Aşama 2: Tapu ve İmar Hukuki Durum Tespiti (Due Diligence)</h4>
                        <p>Tapu Sicil Müdürlüğü (Ypothikofylakio / Ktimatologio) kayıtları taranarak mülk üzerinde ipotek, haciz, şerh veya geçmiş mülkiyet davası bulunmadığı resmi sicil özetiyle doğrulanır.</p>
                        <h4>Aşama 3: Noterlik Satış Sözleşmesi ve Banka Transfer Uyumu</h4>
                        <p>5038/2023 sayılı Kanun uyarınca satış bedelinin tamamı ana başvuru sahibinin kendi banka hesabından satıcının hesabına doğrudan banka havalesi (Wire Transfer) veya bloke çek ile gönderilmelidir; üçüncü kişi ödemeleri başvurunun reddine yol açar. Sözleşme (Symvolaio) imzalandıktan sonra tapu siciline tescil (Metagrafi) ettirilir.</p>
                        <h4>Aşama 4 & 5: Dijital Başvuru, White Paper ve Biyometri</h4>
                        <p>2.000 € tutarındaki e-Paravolo devlet harcı ve tescil belgeleri bakanlık portalına yüklenerek 1 yıl geçerli geçici oturum belgesi (White Paper) üretilir; başvuru tarihinden itibaren 6 ay içinde avukat eşliğinde parmak izi verilerek 5 yıllık kart basım süreci tamamlanır.</p>
                    `
                },
                {
                    topicKey: 'realestate',
                    categoryLabel: 'Gayrimenkul & İmar Hukuku',
                    readTime: '6 dk okuma',
                    title: 'Ticari Mülk Dönüşüm (Conversion) Projelerinde İmar Ruhsatı ve Tapu Güvenliği',
                    excerpt: 'Endüstriyel veya ticari nitelikli yapıların konuta dönüştürülmesinde noter satışı öncesi kontrol edilmesi gereken belediye ruhsatları, yönetim planları ve sözleşme kayıtları.',
                    modalHtml: `
                        <p>250.000 € alt sınır istisnasından yararlanan ticari mülk dönüşüm (conversion) projeleri, standart konut alımlarına kıyasla çok daha yüksek teknik ve hukuki hassasiyet gerektirir.</p>
                        <h4>Noter Sözleşmesi Öncesi Kontrol Edilen Temel Kriterler</h4>
                        <ul>
                            <li><strong>Kullanım Değişikliği Ruhsatı:</strong> Mülkün ofis, dükkan veya endüstriyel statüden konut statüsüne geçişine dair mimari projelerin ve belediye imar müdürlüğü izinlerinin satış sözleşmesi öncesinde hukuken geçerli şekilde onaylanmış olması şarttır.</li>
                            <li><strong>Bağımsız Bölüm ve Yönetim Planı:</strong> Karma kullanımlı binalarda (örneğin Pire, Peristeri, Kallithea veya kentsel dönüşüm bölgelerinde) apartman yönetim planının konut kullanımına ve uzun dönem kiralamaya engel teşkil etmediği teyit edilmelidir.</li>
                            <li><strong>Satıcı Sorumluluk Kayıtları:</strong> Matbu satış metinleri yerine, dönüşüm işlemlerinin tamamlanması ve idari teslim yükümlülüklerini satıcıya bağlayan cezai şartlı noterlik sözleşmesi kurgulanmalıdır.</li>
                        </ul>
                    `
                },
                {
                    topicKey: 'international',
                    categoryLabel: 'Uluslararası İkamet Hukuku',
                    readTime: '5 dk okuma',
                    title: 'Portekiz 23/2007 Sayılı Yabancılar Yasası, AIMA Süreçleri ve D7 İkamet Vizesi Rehberi',
                    excerpt: 'Portekiz Golden Visa minimal kalış kuralı, D7 pasif gelir ikamet vizesinin gelir ve vergi mukimliği kriterleri ile 5 yıllık vatandaşlık süreci.',
                    modalHtml: `
                        <p>Portekiz ikamet hukuku, <strong>23/2007 sayılı Yabancılar Yasası</strong> ve <strong>56/2023 sayılı Kanun</strong> değişiklikleri çerçevesinde iki farklı ana eksen sunar: düşük kalış şartlı Golden Visa rotası ve fiili yerleşim esaslı D7 İkamet Vizesi.</p>
                        <h4>1. Golden Visa ve Minimal Kalış Kuralı</h4>
                        <p>Golden Visa programında oturum izninin korunması için yılda ortalama <strong>7 gün</strong> (ilk iki yıllık kart döneminde toplam 14 gün) Portekiz'de bulunulması yeterlidir. 23/2007 sayılı Kanunun 98. maddesi uyarınca eş, bağımlı çocuklar ve bakmakla yükümlü olunan ebeveynler aile birleşimine dahil edilebilir.</p>
                        <h4>2. D7 Pasif Gelir Vizesi ve Vergi Mukimliği</h4>
                        <ul>
                            <li>Emeklilik, kira veya fikri mülkiyet gibi düzenli pasif gelirlerin belgelenmesine dayanır (Portekiz asgari ücretine endeksli gelir barajları uygulanır; eş için +%50, her çocuk için +%30 ek karşılık aranır).</li>
                            <li>D7 sahipleri yılın en az 6–8 ayını Portekiz'de geçirir ve Portekiz'de <strong>vergi mükellefi (tax resident)</strong> statüsü kazanabileceği için başvuru öncesi uluslararası vergi planlaması yapılmalıdır.</li>
                        </ul>
                        <h4>3. AIMA Takibi ve 5 Yıllık Vatandaşlık Yolu</h4>
                        <p>SEF yerine kurulan AIMA nezdindeki dijital ön başvuru, biyometrik randevu ve kart basım aşamaları yerel Portekiz Barosu avukatlarıyla takip edilir; 5 yıllık yasal ikamet ve A2 düzeyinde Portekizce şartı sağlandığında vatandaşlık başvurusu gündeme gelebilir.</p>
                    `
                },
                {
                    topicKey: 'international',
                    categoryLabel: 'Usul & Resmi Evrak Rehberi',
                    readTime: '5 dk okuma',
                    title: 'Uluslararası İkamet ve Mülkiyet Dosyalarında Resmi Belge ve Apostil Standartları',
                    excerpt: 'Adli sicil arşiv kayıtları, Formül A/B çok dilli nüfus örnekleri, banka SWIFT dekontları ve e-Paravolo harç belgelerinde şekil şartları.',
                    modalHtml: `
                        <p>İdare hukuku karşısında uluslararası başvuruların eksiksiz kabul edilmesi, sunulan şahsi ve mali belgelerin Lahey Apostil Şerhi ve hedef ülke resmi tercüme kurallarına tam uyumuna bağlıdır.</p>
                        <h4>Temel Hukuki Evrak Grupları</h4>
                        <ul>
                            <li><strong>Şahsi ve Aile Bağı Belgeleri:</strong> En az iki yıl geçerli pasaport suretleri, arşiv kayıtlı adli sicil belgesi, aile bağlarını kanıtlayan vukuatlı nüfus kayıt örneği ile uluslararası Formül A (doğum) ve Formül B (evlenme) belgeleri.</li>
                            <li><strong>Sağlık ve Biyometri Evrakları:</strong> Hedef ülke göç idaresi teminat standartlarını karşılayan geçerli sağlık sigortası poliçesi ve dijital sistem uyumlu biyometrik fotoğraflar.</li>
                            <li><strong>Mülkiyet ve Ödeme İspat Belgeleri:</strong> Noterlik satış sözleşmesi, tapu tescil belgesi, hukuki takyidat temizlik raporu ve başvurucu hesabından doğrudan yapılan transferi kanıtlayan resmi banka dekontu / SWIFT mesajı.</li>
                            <li><strong>İdari Harç ve Vergi Kayıtları:</strong> Yabancı vergi kimlik belgesi (AFM / NIF) ve elektronik devlet harcı (örneğin 2.000 € e-Paravolo ve 16 € kart basım harcı) makbuzları.</li>
                        </ul>
                    `
                }
            ],
            faqs: [
                [
                    'Yurt içi ve yurt dışı hukuki işlemler vekaletname ile uzaktan yürütülebilir mi?',
                    'Evet. Noterlikler veya ilgili ülke başkonsoloslukları nezdinde usulüne uygun düzenlenen özel yetkili vekaletname (Power of Attorney) ile vergi kimliği alımı, tapu sicil incelemesi, sözleşme imzalanması ve dijital bakanlık başvuruları müvekkilin seyahat etmesine gerek kalmaksızın yürütülebilmektedir. Yalnızca biyometrik parmak izi ibrazı gibi şahsen katılım gerektiren idari adımlarda randevu organize edilerek avukat eşliği sağlanır.'
                ],
                [
                    'Taşınmaz alımlarında hukuki durum tespiti (Due Diligence) neleri kapsar?',
                    'Tapu kütüğündeki geçmiş mülkiyet zinciri, ipotek, haciz, intifa ve şerh kayıtları, belediye imar durumu, yapı kullanım izinleri, ticari dönüşüm (conversion) projelerinde ruhsat onayı ve kat mülkiyeti yönetim planındaki kiralama/kullanım kısıtları incelenerek yazılı rapor sunulur.'
                ],
                [
                    'Diyarbakır dışındaki veya yurt dışındaki müvekkillere danışmanlık veriliyor mu?',
                    'Evet. Kayapınar / Diyarbakır merkez ofisimiz üzerinden Türkiye genelindeki müvekkillerimize ve yurt dışında yerleşik kişilere çevrim içi görüntülü toplantı, dijital belge incelemesi ve yerel çözüm ortağı avukat ağımız aracılığıyla kesintisiz hukuki destek sağlanmaktadır.'
                ],
                [
                    'Avrupa oturum programlarında aile bireyleri başvuruya dahil edilebilir mi?',
                    'İlgili ülke mevzuatındaki şartlar çerçevesinde hem Yunanistan (5038/2023 m.100) hem de Portekiz (23/2007 m.98) başvurularında eş ve bağımlı çocuklar kapsama alınabilmektedir. Yunanistan mevzuatı ayrıca uygun koşullarda her iki eşin anne ve babasını kapsayan üç kuşak aile birleşimine imkan tanımaktadır.'
                ],
                [
                    'Ön görüşme öncesinde hangi bilgi veya belgelerin paylaşılması faydalıdır?',
                    'Dava ve uyuşmazlık dosyalarında mevcut tebligat, sözleşme veya idari karar örneğinin; taşınmaz ve uluslararası ikamet başvurularında ise hedeflenen ülke/işlem türünün kısaca belirtilmesi, ilk görüşmede somut bir hukuki yol haritası çıkarılmasını hızlandırır.'
                ]
            ]
        },

        en: {
            docTitle: 'LawLab Legal & Advisory | Att. Ahmet Kerim TÜCER',
            metaDesc: 'Founded by Attorney Ahmet Kerim TÜCER, LawLab Legal & Advisory provides real estate & zoning law, corporate contracts, administrative litigation, and European residence & cross-border legal coordination.',
            skipLink: 'Skip to content',
            topbarLocation: 'Fırat Dist. Mega Aslan Plaza Fl:8 No:42 · Kayapınar / Diyarbakır',
            brandSub: 'Att. Ahmet Kerim TÜCER',
            navAbout: 'About',
            navPractice: 'Practice Areas',
            navInternational: 'European Desk',
            navPublications: 'Insights & Guides',
            navMethodology: 'Methodology',
            navContact: 'Contact',
            navCta: 'Schedule Consultation',
            heroBadge: 'Diyarbakır HQ · Domestic & Cross-Border Legal Practice',
            heroTitle: 'Where Legal Assurance Meets <em>Analytical Strategy.</em>',
            heroLead: 'Founded by Attorney Ahmet Kerim TÜCER, LawLab manages real estate and zoning law, commercial contracts, administrative disputes, and European Union residence & cross-border regulatory compliance with preventive legal discipline.',
            heroPrimaryCta: 'Preliminary Legal Assessment',
            heroSecondaryCta: 'Explore Practice Areas',
            pillar1Title: 'Attorney-Led Counsel',
            pillar1Desc: 'Direct oversight by qualified legal counsel from power of attorney to registration and litigation.',
            pillar2Title: 'Due Diligence Focus',
            pillar2Desc: 'Comprehensive pre-transaction scrutiny across title deeds, zoning permits, contracts, and filings.',
            pillar3Title: 'European Coordination',
            pillar3Desc: 'Integrated cross-border case management with bar-registered local counsel in Greece and Portugal.',
            portraitRole: 'Founding Attorney · LawLab Legal & Advisory',
            portraitLoc: 'Kayapınar, Diyarbakır · Domestic & International Practice',
            auth1: 'Preventive Law & Contract Architecture',
            auth2: 'Title Deed, Zoning & Property Due Diligence',
            auth3: 'Greece & Portugal Residence Legislation',
            auth4: 'Attorney-Client Privilege & Transparent Reporting',
            aboutEyebrow: 'About Us · Founding Vision',
            aboutTitle: 'Combining Classical Legal Advocacy with Modern Regulatory Engineering',
            aboutP1: 'Headquartered in Kayapınar, Diyarbakır, LawLab Legal & Advisory was established by Attorney Ahmet Kerim TÜCER to provide clients with comprehensive legal protection across both domestic litigation/advisory matters and cross-border administrative and real estate transactions.',
            aboutP2: 'At the core of the “LawLab” philosophy is treating legal matters not merely as disputes defended after they arise, but as structured legal engagements engineered upfront through contract architecture, title and zoning registry audits, administrative compliance checks, and statutory analysis.',
            aboutP3: 'Alongside our representation before Turkish courts and administrative authorities, we coordinate European residence applications—principally in Greece and Portugal—cross-border property acquisitions, Power of Attorney execution, and multi-jurisdictional filings in collaboration with locally licensed partner attorneys.',
            aboutQuote: '“Effective legal representation is measured not merely by how one reacts when risk materializes, but by the statutory and documentary discipline built before risk arises.”',
            prin1Title: 'Preventive Law & Risk Scrutiny',
            prin1Desc: 'Commercial agreements, property acquisitions, and official filings undergo written legal risk and sanction checks prior to execution.',
            prin2Title: 'Direct & Transparent Case Tracking',
            prin2Desc: 'Clients monitor every procedural milestone, filing record, and statutory deadline through direct communication with responsible counsel.',
            prin3Title: 'Cross-Border Regulatory Compliance',
            prin3Desc: 'Apostille legalization, consular certifications, strict banking wire rules, and target-country immigration/property statutes are verified in parallel.',
            prin4Title: 'Professional Ethics & Confidentiality',
            prin4Desc: 'Client confidentiality is safeguarded under Turkish Attorneyship Law No. 1136, Bar Association Ethics Rules, and Data Protection Law No. 6698.',
            practiceEyebrow: 'Expertise & Practice Areas',
            practiceTitle: 'Multidisciplinary Legal Advisory & Litigation Representation',
            practiceLead: 'We deliver statute-driven legal analysis and diligent representation across core legal disciplines required by private clients and businesses.',
            inspectScope: 'Review Legal Scope',
            intlEyebrow: 'Cross-Border Practice · European Desk',
            intlTitle: 'Greece & Portugal Residence and Real Estate Law Coordination',
            intlLead: 'We approach European residence filings not as commercial brokerage, but as strictly regulated administrative and property law proceedings—coordinated end-to-end between our Diyarbakır headquarters and bar-registered local counsel.',
            greeceDeskLabel: 'Greece Legal Desk',
            greeceDeskTitle: 'Property Due Diligence, Conversion Permit Audit & Residence Filing',
            greeceDeskDesc: 'Following Greece’s New Immigration Code (Law 5038/2023) and Law 5100/2024 amendments, regional thresholds, the 120 m² single-property rule, and €250,000 commercial conversion/restoration exemptions require rigorous legal verification.',
            grStep1: 'Consular or notarial Power of Attorney (PoA), Greek Tax Number (AFM), and compliant bank account setup.',
            grStep2: 'Land Registry (Ktimatologio) encumbrance audit and municipal zoning permit verification for conversion projects.',
            grStep3: 'Notarial Sale Contract (Symvolaio), registry transcription (Metagrafi), e-Paravolo fee, and digital White Paper filing.',
            grStep4: 'Contractual safeguards against short-term rental (Airbnb) and corporate seat registration bans (€50,000 fine & revocation risk).',
            grMetric1Label: 'Family Scope',
            grMetric1Val: '3-Generation Reunification',
            grMetric2Label: 'Physical Stay Rule',
            grMetric2Val: '0 Days (Ownership-Based)',
            grMetric3Label: 'Typical Timeline',
            grMetric3Val: '4 – 6 Months',
            portugalDeskLabel: 'Portugal Legal Desk',
            portugalDeskTitle: 'Golden Visa Compliance, D7 Residence Visa & Citizenship Planning',
            portugalDeskDesc: 'Under Portugal’s Foreigners Law (Lei n.º 23/2007) and AIMA administrative procedures, eligibility documentation, fiscal representation, and long-term citizenship pathways are coordinated with Portuguese Bar counsel.',
            ptStep1: 'Portuguese Tax Identification Number (NIF), fiscal representation, and banking compliance.',
            ptStep2: 'Preparation of criminal record, civil status, and eligibility documents under Apostille and certification standards.',
            ptStep3: 'AIMA digital portal submission, biometric appointment tracking, and administrative follow-up.',
            ptStep4: 'Tax residency and physical stay legal planning for D7 Passive Income Residence Visa applicants.',
            ptMetric1Label: 'Minimal Stay',
            ptMetric1Val: 'Avg. 7 Days / Year',
            ptMetric2Label: 'Citizenship Route',
            ptMetric2Val: '5 Years + A2 Language',
            ptMetric3Label: 'Family Reunification',
            ptMetric3Val: 'Article 98 Scope',
            compTitle: 'Statutory Comparison Summary: Greece & Portugal',
            compSub: 'Key legal framework differences across family eligibility, physical presence obligations, and long-term citizenship rules.',
            compCta: 'Request Eligibility Review',
            thCriteria: 'Legal Criterion',
            thGreece: 'Greece (Law 5038/2023 & 5100/2024)',
            thPortugal: 'Portugal (Lei 23/2007 & 56/2023)',
            row1Head: 'Core Legal Focus',
            row1Gr: 'Real property title, Land Registry transcription (Metagrafi), and zoning/conversion permit compliance',
            row1Pt: 'Regulated program eligibility, documentary compliance, and AIMA administrative review',
            row2Head: 'Family Reunification',
            row2Gr: 'Three generations: spouse, children under 21 (extendable to 24), and parents of both spouses',
            row2Pt: 'Under Art. 98: spouse, minor/student dependent children, and dependent parents',
            row3Head: 'Annual Stay Obligation',
            row3Gr: '0 days physical stay required to maintain residence (continued property ownership required)',
            row3Pt: 'Avg. 7 days/year for Golden Visa; 6–8 months/year actual residence for D7 Visa',
            row4Head: 'Citizenship Pathway',
            row4Gr: '7 years continuous actual residence (≥183 days/year), tax residency, and Greek language/civics exam',
            row4Pt: 'Completion of 5 years legal residence, clean criminal record, and A2 Portuguese proficiency',
            pubEyebrow: 'LawLab Legal Bulletin',
            pubTitle: 'Statutory Analyses & Practice Guides',
            pubLead: 'Briefings on legislative amendments, real estate due diligence standards, and cross-border administrative procedures.',
            filterAll: 'All',
            filterIntl: 'International Residence',
            filterRe: 'Real Estate & Zoning',
            filterProc: 'Procedure & Contracts',
            readArticleBtn: 'Read Analysis →',
            readArticleLink: 'Read Full Briefing',
            featuredHighlightsTitle: 'Key Topics Covered',
            methodEyebrow: 'Our Methodology',
            methodTitle: 'A Four-Stage Legal Verification Architecture Across Every Mandate',
            step1Title: 'Preliminary Review & Statutory Mapping',
            step1Desc: 'We evaluate the dispute or proposed transaction, identifying applicable domestic/foreign statutes, timelines, and legal risks.',
            step2Title: 'Legal Due Diligence & Document Audit',
            step2Desc: 'Title registries, municipal zoning files, corporate records, and official certificates are audited prior to commitment.',
            step3Title: 'Contract Drafting & Official Filing',
            step3Desc: 'Tailored protective agreements are drafted, and court, land registry, or immigration filings are formally executed.',
            step4Title: 'Transparent Reporting & Completion',
            step4Desc: 'Administrative approvals, hearings, biometrics, and registrations are tracked with clear client reporting through completion.',
            faqEyebrow: 'Frequently Asked Questions',
            faqTitle: 'Common Questions on Legal Representation & Procedure',
            faqLead: 'General informational answers regarding Powers of Attorney, property due diligence, and cross-border filings.',
            contactEyebrow: 'Contact & Consultation',
            contactTitle: 'Connect Directly Regarding Your Legal Matter',
            contactDesc: 'Request an appointment with our headquarters to evaluate regulatory compliance, contract structuring, or litigation strategy.',
            contactLawyerLabel: 'Founding Attorney',
            contactOfficeLabel: 'Head Office',
            contactPhoneLabel: 'Phone & WhatsApp',
            contactEmailLabel: 'Corporate Email',
            contactHoursLabel: 'Office Hours',
            contactHoursVal: 'Monday – Friday · 09:00 – 18:00',
            waDirectBtn: 'Contact via WhatsApp',
            mapDirectionsBtn: 'Get Directions',
            formHeading: 'Consultation & Information Request Form',
            formSubheading: 'Submit your inquiry details and our office will review and respond during business hours.',
            labelName: 'Full Name *',
            labelPhone: 'Phone *',
            labelEmail: 'Email *',
            labelTopic: 'Practice Area *',
            labelMessage: 'Matter Summary *',
            phName: 'Your Full Name',
            phPhone: '+90 (5xx) xxx xx xx',
            phEmail: 'name@domain.com',
            phMessage: 'Briefly outline the nature of your legal inquiry or matter...',
            optSelect: 'Select...',
            optIntl: 'Immigration & European Residence Law (Greece / Portugal)',
            optRe: 'Real Estate, Title & Zoning Law',
            optCorp: 'Corporate, Commercial & Contract Law',
            optAdmin: 'Administrative & Tax Law',
            optEnf: 'Enforcement, Debt Recovery & Bankruptcy',
            optLabor: 'Employment Law, Mediation & Private Law',
            consentHtml: 'I have read the <a href="kvkk.html?lang=en">Data Protection Notice (KVKK)</a> and consent to the processing of my personal data for evaluating my inquiry.',
            submitBtn: 'Create Consultation Request',
            footerDesc: 'A law and advisory practice uniting domestic litigation and corporate counsel with cross-border property and European residence legislation expertise.',
            footerNavTitle: 'Firm',
            footerLegalTitle: 'Legal & Compliance',
            footerContactTitle: 'Contact',
            linkKvkk: 'Data Protection Notice (KVKK)',
            linkPrivacy: 'Privacy Policy',
            linkDisclaimer: 'Legal Disclaimer & Ethics',
            footerEthicalNotice: 'Legal Notice: All materials, statutory summaries, and publications on this website are provided solely for general informational purposes and do not constitute legal advice, formal opinion, or commercial advertising. Every matter is evaluated individually under its specific facts and current legislation in compliance with the Union of Turkish Bar Associations Professional Rules and Attorneyship Law No. 1136.',
            copyright: '© 2026 LawLab Legal & Advisory — Att. Ahmet Kerim TÜCER. All rights reserved.',
            modalFootNote: 'Provided for general informational purposes; contact our office for case-specific legal assessment.',
            modalCta: 'Schedule Consultation on This Topic',
            formValidationErr: 'Please complete all required fields and accept the Data Protection Notice.',
            formReadyMsg: 'Your consultation summary is ready. You may transmit it directly to our office via either channel below:',
            sendViaWa: 'Send via WhatsApp',
            sendViaMail: 'Send via Email',
            practices: [
                {
                    topicKey: 'international',
                    kicker: 'Practice Area · Law 5038/2023, Lei 23/2007 & Immigration Law',
                    title: 'Foreigners, Immigration & European Residence Law',
                    summary: 'End-to-end legal coordination for European residence programs in Greece and Portugal, D7 visas, family reunification, and citizenship pathways.',
                    bullets: [
                        'Consular & notarial Power of Attorney (PoA) execution',
                        'Golden Visa & D7 residence compliance verification',
                        'Multi-generation family filings and permit renewals'
                    ],
                    modalHtml: `
                        <p>Residence permit and long-term stay applications across European Union jurisdictions are strictly regulated administrative proceedings. LawLab structures each file in direct compliance with target-country legislation to safeguard client rights.</p>
                        <h4>Scope of Legal Services</h4>
                        <ul>
                            <li>Greece Golden Visa filings under Law 5038/2023 (Article 100) and Law 5100/2024 property and conversion frameworks.</li>
                            <li>Portugal Golden Visa and D7 Passive Income Residence Visa preparation and AIMA administrative follow-up under Law 23/2007 and Law 56/2023.</li>
                            <li>Drafting and legalization of consular/notarial Powers of Attorney (PoA) and Apostille compliance.</li>
                            <li>Foreign tax identification (AFM / NIF), banking compliance, and verification of statutory wire transfer rules.</li>
                            <li>Family reunification filings covering spouses, dependent children, and eligible parents, plus renewal and citizenship planning.</li>
                        </ul>
                    `
                },
                {
                    topicKey: 'realestate',
                    kicker: 'Practice Area · Civil Code, Zoning Law & Land Registry',
                    title: 'Real Estate, Title & Zoning Law',
                    summary: 'Comprehensive title encumbrance due diligence, zoning and commercial conversion permit audits, and protective sale contracts in domestic and cross-border transactions.',
                    bullets: [
                        'Title registry, mortgage, lien & encumbrance clearance',
                        'Zoning plan, building permit & conversion audits',
                        'Title litigation, commercial leases & condominium law'
                    ],
                    modalHtml: `
                        <p>Both in domestic real estate developments and cross-border property acquisitions, the decisive safeguard is rigorous pre-contract <strong>Legal Due Diligence</strong> prior to any transfer of funds.</p>
                        <h4>Scope of Legal Services</h4>
                        <ul>
                            <li>Title registry and cadastral searches for mortgages, liens, usufructs, annotations, and historical ownership disputes.</li>
                            <li>Municipal zoning compliance, occupancy permits, and verification of commercial-to-residential conversion permits.</li>
                            <li>Drafting construction-for-land-share contracts, preliminary sale agreements, and customized notarial sale deeds.</li>
                            <li>Representation in title cancellation/registration suits, partition actions, expropriation, and lease disputes.</li>
                        </ul>
                    `
                },
                {
                    topicKey: 'corporate',
                    kicker: 'Practice Area · Commercial Code & Code of Obligations',
                    title: 'Corporate, Commercial & Contract Law',
                    summary: 'Preventive counsel for corporate governance, commercial contract negotiation, share transfers, and cross-border payment compliance.',
                    bullets: [
                        'Commercial sale, service, lease & shareholder contracts',
                        'Company formation, articles & general assembly resolutions',
                        'Cross-border banking wire & contractual compliance'
                    ],
                    modalHtml: `
                        <p>Most commercial disputes stem from boilerplate or ambiguous contractual clauses. LawLab establishes resilient contract architecture before obligations are signed.</p>
                        <h4>Scope of Legal Services</h4>
                        <ul>
                            <li>Incorporation of joint-stock and limited liability companies, articles amendments, and corporate resolutions.</li>
                            <li>Share purchase agreements, shareholders' agreements (SHA), NDAs, supply, distribution, and service contracts.</li>
                            <li>Ongoing corporate legal retainer services, internal regulatory compliance, and risk audits.</li>
                        </ul>
                    `
                },
                {
                    topicKey: 'administrative',
                    kicker: 'Practice Area · Administrative Procedure & Tax Law',
                    title: 'Administrative & Tax Law',
                    summary: 'Annulment and full-remedy actions against administrative and municipal acts, alongside domestic and international tax registration compliance.',
                    bullets: [
                        'Annulment actions & stay of execution petitions',
                        'Municipal permit & zoning fine objections',
                        'Foreign tax ID (AFM / NIF) & tax residency analysis'
                    ],
                    modalHtml: `
                        <p>Administrative acts are subject to strict statutory filing deadlines. Timely, technically substantiated legal challenges are essential to prevent irreversible loss of rights.</p>
                        <h4>Scope of Legal Services</h4>
                        <ul>
                            <li>Annulment lawsuits with stay-of-execution requests against municipal fines, license revocations, and zoning decisions.</li>
                            <li>Full-remedy compensation actions arising from unlawful administrative acts or omissions.</li>
                            <li>Tax assessment disputes, reconciliation representation, and cross-border tax residency evaluations.</li>
                        </ul>
                    `
                },
                {
                    topicKey: 'enforcement',
                    kicker: 'Practice Area · Enforcement & Bankruptcy Law',
                    title: 'Enforcement, Bankruptcy & Debt Recovery',
                    summary: 'Strategic recovery of commercial and private receivables, foreclosure of collateral, precautionary attachment orders, and negative declaratory actions.',
                    bullets: [
                        'Judgment, non-judgment & negotiable instrument enforcement',
                        'Precautionary attachment, pledge & mortgage foreclosure',
                        'Objection annulment, negative clearance & clawback suits'
                    ],
                    modalHtml: `
                        <p>Timely lawful collection of receivables is vital to commercial continuity, just as swift procedural defense is critical against unfounded enforcement claims.</p>
                        <h4>Scope of Legal Services</h4>
                        <ul>
                            <li>Enforcement proceedings based on checks, promissory notes, arbitral awards, and court judgments.</li>
                            <li>Precautionary attachment petitions and foreclosure of mortgages and pledges.</li>
                            <li>Annulment of objections, negative declaratory lawsuits, restitution claims, and fraudulent conveyance actions.</li>
                        </ul>
                    `
                },
                {
                    topicKey: 'labor',
                    kicker: 'Practice Area · Labor Law & Dispute Resolution',
                    title: 'Employment Law, Damages & Mediation',
                    summary: 'Workplace regulatory compliance, representation in mandatory and voluntary mediation, and tort, compensation, and inheritance law matters.',
                    bullets: [
                        'Employment contracts, termination compliance & severance',
                        'Representation in commercial and employment mediation',
                        'Pecuniary/non-pecuniary damages & inheritance division'
                    ],
                    modalHtml: `
                        <p>Adherence to statutory procedure from hiring through termination mitigates substantial employment liabilities and streamlines dispute resolution.</p>
                        <h4>Scope of Legal Services</h4>
                        <ul>
                            <li>Drafting employment agreements, workplace policies, and legally compliant termination notices.</li>
                            <li>Representation in reinstatement claims, severance/overtime litigation, and mandatory mediation sessions.</li>
                            <li>Compensation lawsuits, certificates of inheritance, wills, and estate distribution agreements.</li>
                        </ul>
                    `
                }
            ],
            publications: [
                {
                    topicKey: 'international',
                    categoryLabel: 'International Residence Law',
                    readTime: '6 min read',
                    title: 'Greece Golden Visa Legislation Under Laws 5038/2023 & 5100/2024 and Statutory Usage Restrictions',
                    excerpt: 'Legal analysis of Article 100 of the Greek Immigration Code, €800,000 / €400,000 regional tiers, the €250,000 commercial conversion exemption, and short-term rental sanctions.',
                    highlights: [
                        'Law 5038/2023 Article 100 Statutory Framework',
                        'Law 5100/2024 Regional Tiers & 120 m² Single-Asset Rule',
                        '€250,000 Commercial Conversion & Listed Restoration Route',
                        '€50,000 Administrative Fine & Permit Revocation Sanctions'
                    ],
                    modalHtml: `
                        <p>Greece's Golden Visa framework is governed by <strong>Article 100 of Law 5038/2023 (New Immigration Code)</strong>, as amended by <strong>Article 64 of Law 5100/2024</strong> and clarified under Ministry Circular No. 6/2024.</p>
                        <h4>1. Regional Thresholds & Single-Property Requirement</h4>
                        <ul>
                            <li><strong>€800,000 Tier:</strong> Applies across Attica (greater Athens), Thessaloniki, Mykonos, Santorini, and islands with a population exceeding 3,100 residents.</li>
                            <li><strong>€400,000 Tier:</strong> Applies to all other mainland and regional jurisdictions across Greece.</li>
                            <li><strong>120 m² Rule:</strong> Both tiers require acquisition of a single distinct property unit measuring at least 120 square meters of net area.</li>
                        </ul>
                        <h4>2. The €250,000 Statutory Exemptions</h4>
                        <ul>
                            <li><strong>Commercial-to-Residential Conversion:</strong> Acquisition of commercial, office, or industrial property legally converted into residential use regardless of region.</li>
                            <li><strong>Listed Building Restoration:</strong> Acquisition and full restoration of historically or architecturally listed buildings.</li>
                        </ul>
                        <h4>3. Mandatory Usage Prohibitions & Penalties</h4>
                        <p>Properties qualifying under Article 100 are strictly prohibited from short-term tourist leasing (e.g., Airbnb) and may not be registered as a company headquarters or branch. Violations trigger an administrative fine of <strong>€50,000</strong> and immediate revocation of the residence permit.</p>
                    `
                },
                {
                    topicKey: 'international',
                    categoryLabel: 'Procedure & Contract Law',
                    readTime: '7 min read',
                    title: 'Power of Attorney (PoA), Legal Due Diligence & Regulated Banking Wire Rules in Cross-Border Filings',
                    excerpt: 'A five-stage procedural roadmap from consular PoA execution and land registry audits to wire compliance, White Paper issuance, and biometrics.',
                    modalHtml: `
                        <p>Cross-border property acquisition linked to residence permits requires strict adherence to administrative and banking formalities across five legal stages:</p>
                        <h4>Stage 1: Power of Attorney, AFM & Banking</h4>
                        <p>A specialized Power of Attorney is executed before a public notary or Consulate, enabling counsel to obtain a Greek Tax Identification Number (AFM) and initiate compliant banking arrangements without requiring prior travel.</p>
                        <h4>Stage 2: Land Registry Legal Due Diligence</h4>
                        <p>Counsel audits the competent Land Registry / Cadastre (Ktimatologio) to verify clean title free of mortgages, liens, claims, or zoning defects.</p>
                        <h4>Stage 3: Notarial Deed & Strict Wire Transfer Compliance</h4>
                        <p>Under Law 5038/2023, the entire qualifying consideration must be transferred directly from the main applicant's personal bank account to the seller's account via regulated bank wire or bank cheque. Third-party transfers invalidate eligibility. Following execution of the Notarial Sale Deed (Symvolaio), title is transcribed (Metagrafi).</p>
                        <h4>Stages 4 & 5: Digital Submission, White Paper & Biometrics</h4>
                        <p>Upon uploading the €2,000 e-Paravolo state fee and registry certificates, the Ministry portal issues the 1-year temporary confirmation (White Paper), followed by biometric submission within 6 months accompanied by counsel.</p>
                    `
                },
                {
                    topicKey: 'realestate',
                    categoryLabel: 'Real Estate & Zoning Law',
                    readTime: '6 min read',
                    title: 'Zoning Permits & Contractual Safeguards in Commercial-to-Residential Conversion Projects',
                    excerpt: 'Essential municipal permit audits, condominium bylaws checks, and seller liability clauses required prior to signing €250,000 conversion deeds.',
                    modalHtml: `
                        <p>Commercial-to-residential conversion projects qualifying under the €250,000 statutory exception demand heightened technical and legal scrutiny compared to standard residential resales.</p>
                        <h4>Key Pre-Contract Audit Checkpoints</h4>
                        <ul>
                            <li><strong>Change-of-Use Permit Verification:</strong> Architectural plans and municipal urban-planning approvals converting industrial/office status to residential status must be verified prior to executing the final sale deed.</li>
                            <li><strong>Horizontal Property & Bylaws Audit:</strong> Building regulations and horizontal property deeds must permit residential occupancy and long-term leasing.</li>
                            <li><strong>Protective Seller Covenants:</strong> Customized notarial contracts should allocate conversion completion warranties and regulatory compliance liabilities squarely onto the developer/seller.</li>
                        </ul>
                    `
                },
                {
                    topicKey: 'international',
                    categoryLabel: 'International Residence Law',
                    readTime: '5 min read',
                    title: 'Portugal Foreigners Law No. 23/2007, AIMA Procedures & D7 Residence Visa Guide',
                    excerpt: 'Comparing Portugal’s Golden Visa minimal stay rule, D7 passive income & tax residency obligations, and the five-year citizenship route.',
                    modalHtml: `
                        <p>Portuguese immigration law under <strong>Law No. 23/2007</strong> and <strong>Law No. 56/2023</strong> provides distinct legal pathways depending on whether the applicant intends minimal physical presence or actual relocation.</p>
                        <h4>1. Golden Visa & Minimal Stay Rule</h4>
                        <p>Golden Visa holders maintain residence status with an average physical stay of just <strong>7 days per year</strong> (14 days across the initial two-year permit). Article 98 enables family reunification for spouses, dependent children, and eligible parents.</p>
                        <h4>2. D7 Passive Income Visa & Tax Residency</h4>
                        <ul>
                            <li>Designed for applicants documenting stable passive income (pensions, rentals, dividends, intellectual property) indexed to Portugal's statutory minimum wage (+50% for spouse, +30% per child).</li>
                            <li>Requires actual residence in Portugal (typically 6–8 months annually) and generally triggers Portuguese <strong>tax residency</strong>, making pre-application tax planning essential.</li>
                        </ul>
                        <h4>3. AIMA Processing & 5-Year Citizenship Route</h4>
                        <p>Digital pre-filing, biometric scheduling before AIMA, and statutory timelines are coordinated with Portuguese Bar counsel; after 5 years of legal residence and A2 Portuguese certification, applicants may apply for citizenship.</p>
                    `
                },
                {
                    topicKey: 'international',
                    categoryLabel: 'Official Documentation Guide',
                    readTime: '5 min read',
                    title: 'Official Documentation, Apostille & Banking Proof Standards in International Filings',
                    excerpt: 'Formal validity requirements for criminal record certificates, multilingual civil registry extracts, SWIFT confirmations, and state fee receipts.',
                    modalHtml: `
                        <p>Administrative acceptance of cross-border residence and property filings depends on strict compliance with Hague Apostille legalization and certified translation rules.</p>
                        <h4>Core Documentary Categories</h4>
                        <ul>
                            <li><strong>Personal & Civil Status Records:</strong> Passports with sufficient validity, archived criminal record certificates, family registry extracts, and multilingual Formula A (birth) and Formula B (marriage) certificates.</li>
                            <li><strong>Insurance & Biometric Standards:</strong> Immigration-compliant health insurance coverage and specification-grade biometric photographs.</li>
                            <li><strong>Title & Payment Evidence:</strong> Notarial sale deed, land registry certificate, legal due diligence clearance report, and official bank wire / SWIFT confirmations from the main applicant's account.</li>
                            <li><strong>Fiscal & State Fee Receipts:</strong> Foreign tax ID certificate (AFM / NIF) and electronic state fee receipts (such as the €2,000 e-Paravolo and €16 card issuance fee).</li>
                        </ul>
                    `
                }
            ],
            faqs: [
                [
                    'Can domestic and cross-border legal procedures be conducted remotely via Power of Attorney?',
                    'Yes. Through a properly executed notarial or consular Power of Attorney, tax ID issuance, land registry due diligence, contract execution, and digital ministry filings can be completed without requiring client travel. Personal attendance is generally required only for biometric fingerprint appointments, where counsel accompanies you.'
                ],
                [
                    'What does real estate Legal Due Diligence cover before purchasing a property?',
                    'Our audit covers historical chain of title, mortgages, liens, easements, annotations, municipal zoning compliance, occupancy permits, change-of-use approvals in conversion projects, and leasing/usage restrictions in building bylaws, delivered in a written legal report.'
                ],
                [
                    'Do you advise clients located outside Diyarbakır or living abroad?',
                    'Yes. From our Kayapınar / Diyarbakır headquarters, we advise clients across Türkiye and abroad via video consultations, digital document review, and coordinated local counsel representation.'
                ],
                [
                    'Can family members be included in European residence applications?',
                    'Under statutory conditions, both Greece (Law 5038/2023 Art. 100) and Portugal (Law 23/2007 Art. 98) cover spouses and dependent children. Greece additionally allows three-generation family coverage including the parents of both spouses.'
                ],
                [
                    'What information is helpful to share prior to an initial consultation?',
                    'For litigation or administrative matters, sharing relevant notices, contracts, or decisions—and for property or international residence inquiries, indicating your target jurisdiction and objective—helps establish a clear legal roadmap during the initial meeting.'
                ]
            ]
        }
    };

    /* ----------------------------------------------------------------------
       1. Theme Management
       ---------------------------------------------------------------------- */
    const themeToggle = document.getElementById('themeToggle');
    const iconSun = document.getElementById('iconSun');
    const iconMoon = document.getElementById('iconMoon');

    const syncThemeIcons = () => {
        const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
        if (iconSun) iconSun.hidden = !isDark;
        if (iconMoon) iconMoon.hidden = isDark;
    };

    syncThemeIcons();

    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            const current = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
            const next = current === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-theme', next);
            try {
                localStorage.setItem('lawlab_theme', next);
            } catch (e) { /* ignore storage errors */ }
            syncThemeIcons();
        });
    }

    /* ----------------------------------------------------------------------
       2. Language Management (TR / EN)
       ---------------------------------------------------------------------- */
    const detectInitialLanguage = () => {
        const params = new URLSearchParams(window.location.search);
        const qLang = (params.get('lang') || '').toLowerCase();
        if (qLang === 'en' || qLang === 'tr') return qLang;
        try {
            const saved = (localStorage.getItem('lawlab_lang') || '').toLowerCase();
            if (saved === 'en' || saved === 'tr') return saved;
        } catch (e) { /* ignore */ }
        return 'tr';
    };

    let currentLang = detectInitialLanguage();

    const applyLanguage = (lang) => {
        const dict = I18N[lang] || I18N.tr;
        currentLang = lang;
        document.documentElement.lang = lang;
        document.title = dict.docTitle;

        try {
            localStorage.setItem('lawlab_lang', lang);
        } catch (e) { /* ignore */ }

        // Update URL query cleanly when run over http/https
        if (window.location.protocol === 'http:' || window.location.protocol === 'https:') {
            const url = new URL(window.location.href);
            if (lang === 'tr') url.searchParams.delete('lang');
            else url.searchParams.set('lang', lang);
            window.history.replaceState(null, '', url.pathname + url.search + url.hash);
        }

        const canonicalEl = document.querySelector('link[rel="canonical"]');
        if (canonicalEl) {
            canonicalEl.setAttribute('href', lang === 'en' ? 'https://lawlab.com.tr/?lang=en' : 'https://lawlab.com.tr/');
        }
        document.querySelectorAll('meta[name="description"], meta[property="og:description"], meta[name="twitter:description"]').forEach((el) => {
            el.setAttribute('content', dict.metaDesc);
        });
        document.querySelectorAll('meta[property="og:title"], meta[name="twitter:title"]').forEach((el) => {
            el.setAttribute('content', dict.docTitle);
        });

        // Plain text nodes
        document.querySelectorAll('[data-i18n]').forEach((el) => {
            const key = el.getAttribute('data-i18n');
            if (dict[key] !== undefined) el.textContent = dict[key];
        });

        // Controlled HTML nodes
        document.querySelectorAll('[data-i18n-html]').forEach((el) => {
            const key = el.getAttribute('data-i18n-html');
            if (dict[key] !== undefined) el.innerHTML = dict[key];
        });

        // Form placeholders
        document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
            const key = el.getAttribute('data-i18n-placeholder');
            if (dict[key] !== undefined) el.setAttribute('placeholder', dict[key]);
        });

        // Practice cards
        dict.practices.forEach((p, idx) => {
            const tEl = document.querySelector(`[data-practice-title="${idx}"]`);
            const sEl = document.querySelector(`[data-practice-summary="${idx}"]`);
            const bEl = document.querySelector(`[data-practice-bullets="${idx}"]`);
            if (tEl) tEl.textContent = p.title;
            if (sEl) sEl.textContent = p.summary;
            if (bEl && Array.isArray(p.bullets)) {
                bEl.innerHTML = p.bullets.map((item) => `<li>${item}</li>`).join('');
            }
        });

        // Publication cards
        dict.publications.forEach((pub, idx) => {
            const cEl = document.querySelector(`[data-pub-cat="${idx}"]`);
            const tmEl = document.querySelector(`[data-pub-time="${idx}"]`);
            const tiEl = document.querySelector(`[data-pub-title="${idx}"]`);
            const exEl = document.querySelector(`[data-pub-excerpt="${idx}"]`);
            const hlEl = document.querySelector(`[data-pub-highlights="${idx}"]`);
            if (cEl) cEl.textContent = pub.categoryLabel;
            if (tmEl) tmEl.textContent = pub.readTime;
            if (tiEl) tiEl.textContent = pub.title;
            if (exEl) exEl.textContent = pub.excerpt;
            if (hlEl && Array.isArray(pub.highlights)) {
                hlEl.innerHTML = pub.highlights.map((h) => `<li>${h}</li>`).join('');
            }
        });

        // FAQs
        dict.faqs.forEach(([q, a], idx) => {
            const qEl = document.querySelector(`[data-faq-q="${idx}"]`);
            const aEl = document.querySelector(`[data-faq-a="${idx}"]`);
            if (qEl) qEl.textContent = q;
            if (aEl) aEl.textContent = a;
        });

        // Language switch buttons
        document.querySelectorAll('[data-lang-btn]').forEach((btn) => {
            btn.classList.toggle('active', btn.getAttribute('data-lang-btn') === lang);
        });
    };

    document.querySelectorAll('[data-lang-btn]').forEach((btn) => {
        btn.addEventListener('click', () => {
            const targetLang = btn.getAttribute('data-lang-btn');
            if (targetLang && targetLang !== currentLang) {
                applyLanguage(targetLang);
            }
        });
    });

    applyLanguage(currentLang);

    /* ----------------------------------------------------------------------
       3. Mobile Navigation & Sticky Header
       ---------------------------------------------------------------------- */
    const siteHeader = document.getElementById('siteHeader');
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const primaryNav = document.getElementById('primaryNav');

    const closeMobileMenu = () => {
        if (!primaryNav || !mobileMenuBtn) return;
        primaryNav.classList.remove('is-open');
        mobileMenuBtn.setAttribute('aria-expanded', 'false');
    };

    if (mobileMenuBtn && primaryNav) {
        mobileMenuBtn.addEventListener('click', () => {
            const isOpen = primaryNav.classList.toggle('is-open');
            mobileMenuBtn.setAttribute('aria-expanded', String(isOpen));
        });

        primaryNav.querySelectorAll('a').forEach((link) => {
            link.addEventListener('click', closeMobileMenu);
        });
    }

    window.addEventListener('scroll', () => {
        if (siteHeader) {
            siteHeader.classList.toggle('is-scrolled', window.scrollY > 12);
        }
    }, { passive: true });

    /* ----------------------------------------------------------------------
       4. Publications Category Filter
       ---------------------------------------------------------------------- */
    const filterButtons = document.querySelectorAll('[data-pub-filter]');
    const pubCards = document.querySelectorAll('[data-pub-card]');

    filterButtons.forEach((btn) => {
        btn.addEventListener('click', () => {
            const filter = btn.getAttribute('data-pub-filter') || 'all';
            filterButtons.forEach((b) => b.classList.toggle('active', b === btn));
            pubCards.forEach((card) => {
                const cat = card.getAttribute('data-category');
                const match = filter === 'all' || cat === filter;
                card.hidden = !match;
            });
        });
    });

    /* ----------------------------------------------------------------------
       5. Modal System (Practice Area Details & Legal Article Reader)
       ---------------------------------------------------------------------- */
    const modal = document.getElementById('detailModal');
    const modalKicker = document.getElementById('modalKicker');
    const modalTitle = document.getElementById('modalTitle');
    const modalBody = document.getElementById('modalBody');
    const modalCtaBtn = document.getElementById('modalCtaBtn');
    const topicSelect = document.getElementById('topic');
    let lastFocusedTrigger = null;
    let activeModalTopic = '';

    const openModal = ({ kicker, title, html, topicKey }, triggerEl) => {
        if (!modal) return;
        lastFocusedTrigger = triggerEl || document.activeElement;
        activeModalTopic = topicKey || '';
        if (modalKicker) modalKicker.textContent = kicker || '';
        if (modalTitle) modalTitle.textContent = title || '';
        if (modalBody) {
            modalBody.innerHTML = html || '';
            modalBody.scrollTop = 0;
        }
        modal.hidden = false;
        document.body.classList.add('modal-open');
        const closeBtn = modal.querySelector('.modal-close');
        if (closeBtn) closeBtn.focus();
    };

    const closeModal = () => {
        if (!modal || modal.hidden) return;
        modal.hidden = true;
        document.body.classList.remove('modal-open');
        if (lastFocusedTrigger && typeof lastFocusedTrigger.focus === 'function') {
            lastFocusedTrigger.focus();
        }
    };

    document.querySelectorAll('[data-open-practice]').forEach((btn) => {
        btn.addEventListener('click', () => {
            const idx = Number(btn.getAttribute('data-open-practice'));
            const dict = I18N[currentLang] || I18N.tr;
            const item = dict.practices[idx];
            if (!item) return;
            openModal({
                kicker: item.kicker,
                title: item.title,
                html: item.modalHtml,
                topicKey: item.topicKey
            }, btn);
        });
    });

    document.querySelectorAll('[data-open-pub]').forEach((btn) => {
        btn.addEventListener('click', () => {
            const idx = Number(btn.getAttribute('data-open-pub'));
            const dict = I18N[currentLang] || I18N.tr;
            const pub = dict.publications[idx];
            if (!pub) return;
            openModal({
                kicker: `${pub.categoryLabel} · ${pub.readTime}`,
                title: pub.title,
                html: pub.modalHtml,
                topicKey: pub.topicKey
            }, btn);
        });
    });

    document.querySelectorAll('[data-modal-close]').forEach((el) => {
        el.addEventListener('click', closeModal);
    });

    if (modalCtaBtn) {
        modalCtaBtn.addEventListener('click', () => {
            if (activeModalTopic && topicSelect) {
                topicSelect.value = activeModalTopic;
            }
            closeModal();
        });
    }

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeModal();
            closeMobileMenu();
        }
    });

    /* ----------------------------------------------------------------------
       6. FAQ Accordion
       ---------------------------------------------------------------------- */
    document.querySelectorAll('#faqList .faq-trigger').forEach((trigger) => {
        trigger.addEventListener('click', () => {
            const item = trigger.closest('.faq-item');
            const panel = item ? item.querySelector('.faq-panel') : null;
            if (!item || !panel) return;

            const isOpen = item.classList.contains('is-open');
            document.querySelectorAll('#faqList .faq-item').forEach((other) => {
                other.classList.remove('is-open');
                const btn = other.querySelector('.faq-trigger');
                const pnl = other.querySelector('.faq-panel');
                if (btn) btn.setAttribute('aria-expanded', 'false');
                if (pnl) pnl.hidden = true;
            });

            if (!isOpen) {
                item.classList.add('is-open');
                trigger.setAttribute('aria-expanded', 'true');
                panel.hidden = false;
            }
        });
    });

    /* ----------------------------------------------------------------------
       7. Consultation Form Handling
       ---------------------------------------------------------------------- */
    const form = document.getElementById('consultationForm');
    const feedback = document.getElementById('formFeedback');

    if (form && feedback) {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const dict = I18N[currentLang] || I18N.tr;

            // Honeypot check
            const hp = form.querySelector('[name="company_website"]');
            if (hp && hp.value.trim() !== '') return;

            const fullName = form.fullName.value.trim();
            const phone = form.phone.value.trim();
            const email = form.email.value.trim();
            const topicVal = form.topic.value;
            const topicText = form.topic.options[form.topic.selectedIndex]?.textContent || '';
            const message = form.message.value.trim();
            const consent = form.kvkkConsent.checked;

            if (!fullName || !phone || !email || !topicVal || !message || !consent) {
                feedback.hidden = false;
                feedback.innerHTML = `<p>${dict.formValidationErr}</p>`;
                return;
            }

            const summaryLines = [
                'LawLab Ön Görüşme Talebi (lawlab.com.tr)',
                `Ad Soyad: ${fullName}`,
                `Telefon: ${phone}`,
                `E-Posta: ${email}`,
                `Hukuk Alanı: ${topicText}`,
                `Konu Özeti: ${message}`
            ];
            const plainSummary = summaryLines.join('\n');
            const waUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(plainSummary)}`;
            const mailSubject = encodeURIComponent(`LawLab Ön Görüşme Talebi — ${fullName}`);
            const mailUrl = `mailto:${CONTACT_EMAIL}?subject=${mailSubject}&body=${encodeURIComponent(plainSummary)}`;

            feedback.hidden = false;
            feedback.innerHTML = `
                <p><strong>${dict.formReadyMsg}</strong></p>
                <div class="form-feedback-actions">
                    <a href="${waUrl}" target="_blank" rel="noopener" class="btn btn-whatsapp">${dict.sendViaWa}</a>
                    <a href="${mailUrl}" class="btn btn-outline">${dict.sendViaMail}</a>
                </div>
            `;
        });
    }

    /* ----------------------------------------------------------------------
       8. Reveal on Scroll & Active Nav Section
       ---------------------------------------------------------------------- */
    const revealEls = document.querySelectorAll('.reveal');
    if ('IntersectionObserver' in window) {
        const io = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    io.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12 });

        revealEls.forEach((el) => io.observe(el));
    } else {
        revealEls.forEach((el) => el.classList.add('is-visible'));
    }
})();
